#ifndef uva_H
#define uva_H

#include <QtGui/QMainWindow>

class uva : public QMainWindow
{
Q_OBJECT
public:
    uva();
    virtual ~uva();
};

#endif // uva_H
